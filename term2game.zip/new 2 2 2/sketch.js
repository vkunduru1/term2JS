  // i have achieved the targets i had set for myself, my targets were:
  //- Add a score system 
  //- Make sure that the keys are in sync with the circles - complex boolean conditions
  //- add game states (start screen / end screen) - boolean variables

  
  
  var i = [];
  var rectPos = [0, 150, 300, 450]; // position of the rectangles
  var circlePos = [100,75,50,25,0]; // 
  var posX = 0;
  var posY = 0;
  var speedX = 0,
      speedY = 4;
  var s = []; // declaring new CIRCLE variable
  var rectWidth = 50;
  var numCircles = 8;
  var counter = 0;
  var colpick={
  x:50,
  y:40,
  w:50,
  h:50
} 
var sqrCol = 255;
var colpickStore = {
  r:255,
  g:255,
  b:255
}
var nextCol = false;
var colStateR = false; 
var ico = {//start button variables
  x: 400,
  y: 300,
  w: 200,
  h: 75
}
var col = 150;
var state = startScreen;


  function setup() {
    createCanvas(550, 600); //creates a canvas with a width and height of 600
    posX = rectPos[random(0, 4)]; // assigns variable posX to appear randomly only at the top of each rect panel.
    fill(155,155,155);
    // initializing CIRCLE variable with a random x
    for (var i = 0; i < numCircles; i++) {
      s[i] = new Circle();
    }
  }

function levelOne(){
      background(0); //draws a black background
      for (var i = 0; i < 4; i++) { // for loop that draws the panels so when var i is 0 and i is less that 4 it draws the panels
        fill(sqrCol,150,150)
        rect(i * 150, 450, rectWidth, 100, 255); // the size, x and y position of the rectangles so i* the x position of the panels that determines how many shall be drawn. 
     
      
      }
      touching = false;
      // two circle functions
      for (i = 0; i < numCircles; i++) {
        s[i].display();
        s[i].move();
        s[i].press();
        if(s[i].y > 450){
          touching = true;
            if(s[i].x < 101 && keyCode == 81 && touching){ //assigning the letter 'Q' to the first panel
              console.log("q")
              s[i].y = 0;
              s[i].x = rectPos[random(0, 4)]
              counter++
              sqrCol = 100
            }else if(s[i].x < 200 && keyCode == 87 && touching){ //assigning the letter 'W' to the second panel
              s[i].y = 0;
              s[i].x = rectPos[random(0, 4)]
              counter++
              sqrCol = 100
            }else if(s[i].x < 400 && keyCode == 69 && touching){ //assigning the letter 'E' to the third panel
              s[i].y = 0;
              s[i].x = rectPos[random(0, 4)]
              counter++
              sqrCol = 100

            }else if(s[i].x < 500 && keyCode == 82 && touching){ //assigning the letter 'R' to the fourth panel.
              s[i].y = 0;
              s[i].x = rectPos[random(0, 4)]
              counter++
              sqrCol = 100

            }else{
              sqrCol = 255
            }
       
        }
      }
      console.log(s.press);
      text(counter,100,100);  //counts how many circles hit the panels.
      text(mouseX,mouseX,mouseY); //co-ordinates of the mouse on canvas.
      fill(sqrCol);
      text('Q', 15, height-10);
      text('W', 175, height-10);
      text('E', 320, height-10);
      text('R', 475, height-10);
}
  function draw() {
    state();
}


function startScreen(){    
  background(255);
  fill(0,0,col);//col is the colour of the rect of the start button changes via hover
  textSize(15);
  text("CLICK TO START", width / 2, height / 3 + 35);
   text("PRESS THE KEYS QWER TO PLAY", width / 3, height / 2 + 50);
  textSize(17);
  fill(255);
  

  if(mouseX>ico.x-120 && mouseX<ico.x+ico.w && mouseY > ico.y-30 && mouseY < ico.y+ico.h){
      col = 255;
      nextCol = true;//mouse hover over start button
      // state = levelOne;
  }else{
    col = 150;//non-hover
  }
    if(nextCol && mouseIsPressed){
    state = levelOne;//whilst hovering and button pressed
  }
}
