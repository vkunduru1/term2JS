function Circle() {file:///private/var/folders/z0/yw385ghx25b584pq4l493q700000gn/T/AppTranslocation/7C3F85D8-117E-4116-B905-2C20C84823BE/d/p5.app/Contents/Resources/app.nw/index.html#
    // these are the coordinates of the circle
    this.x = random(rectPos) + rectWidth / 2;
    this.y = random(circlePos);
    this.size = {
      x: 30,
      y: 30,
      
    };
    this.speed = 3;
    this.r = random(255);
    this.g = random(255);
    this.b = random(255);

    
    this.display = function() {   // call this function to display circle
        strokeWeight(0);
        fill(this.r, this.g, this.b);
        ellipseMode(CENTER);
       ellipse(this.x, this.y, this.size.x, this.size.y);
      }
      
      this.move = function() {    // call this function to move the circle
      this.y += this.speed;       //determines the speed of the ellipse.
      if ((this.y + this.size.y / 2) >= height) { //if statement that makes sure that once the ellipse goes to the bottom of the canvas it reappears at co-ordinate 0.
        this.x = random(rectPos) + rectWidth / 2;//assigns the circle to the center of the rectangles
        this.y = 0;
      } 
    }
    this.press = function(sqr, sqr2){ // when the ellipse touches the panels it returns true.
      if(this.y > sqr && this.y < sqr2){ 
        return true;
      }
      else{
        return false;
      }
    }
  }
 